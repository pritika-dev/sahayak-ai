"""
Shared API key for the victim-facing endpoints (chat, analyze). This is
a simple app-level shared secret — it stops random/automated traffic
from hitting the API, not a specific person from misusing it once
they have your frontend's source (any key embedded in client-side JS
is visible to anyone who opens dev tools/view-source).

For real protection beyond a hackathon demo, move this server-side
(a backend-for-frontend proxy that holds the key, never shipped to the
browser) or replace it with real per-user auth. Rotate this value
before any real deployment — generate a new one with:
    python -c "import secrets; print(secrets.token_hex(24))"
"""
API_KEY = "e59d8c99f3b6b9b992b991988d458d679df9e7e475555dad"
